const AksiyaData =[
    {
        title: "Smartfon",
        description: "Smartfon Tecno Spark Go 2023",
        price: 1359000,
    }
]
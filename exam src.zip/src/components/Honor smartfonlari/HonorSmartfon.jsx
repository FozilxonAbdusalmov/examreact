import React from 'react'
import './HonorSmartfon.css'
import { Link } from 'react-router-dom'
import { FaAngleRight } from "react-icons/fa6";
import { FaHeart } from "react-icons/fa";
import { SlBasket } from "react-icons/sl";

function Honorhonorsmartfon() {
    return (

        <div className='honorsmartfon'>
            <div className='honorsmartfon_item'>
                <h1> Honor samrtfonlari chegirmada <Link>Hammsini Korsatish <FaAngleRight />
                </Link></h1>
            </div>
            <div className='honorsmartfon_container'>


                <div className='honorsmartfon_container_item'>

                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>
                <div className='honorsmartfon_container_item'>
                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>
                <div className='honorsmartfon_container_item'>
                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>
                <div className='honorsmartfon_container_item'>
                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>
                <div className='honorsmartfon_container_item'>
                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>
                <div className='honorsmartfon_container_item'>
                    <FaHeart />
                    <div>

                        <img src="https://minio.alifnasiya.uz/shop/rand/f4/e9/1e/f4e91e59-1434-41ea-9f09-1b151e0fd841.jpg" alt="phone" />
                        <div className='honorsmartfon_container_item_narx'>
                            <span>-15%</span>
                        </div>
                    </div>
                    <p className='rusum'> Смартфон Xiaomi Redmi Note 12 Pro 6/128GB 4G</p>
                    <span> 191 108so'm/oyga </span>
                    <p><s className='honorsmartfon_honorsmartfons'> 3 200 000 so'm </s></p>
                    <p className='narx'>2 698 000 so'm</p>
                    <button> <SlBasket />Savatga</button>
                </div>



            </div>
        </div>
    )
}

export default Honorhonorsmartfon
